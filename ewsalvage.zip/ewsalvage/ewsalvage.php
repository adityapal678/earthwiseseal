<?php
/**
 * Plugin Name: ewsalvage
 * Description: A custom plugin to integrate WooCommerce with Earth Wise Architecture Salvage retail store.
 * Version: 1.0.0
 * Author: Adi
 * Author URI: https://www.upwork.com/freelancers/~01ed35f63346bc8507
 * Text Domain: ewsalvage
 */

// Exit if accessed directly
defined('ABSPATH') || exit;

ini_set('memory_limit', '-1');
ini_set('max_execution_time', '-1');
ini_set('display_errors', 0);

const ewsalvage_API_BASE_URL = 'https://ewsalvage.relationhq.com/';
$version = '1.0.0';

ewsalvage_define_constants($version);
ewsalvage_init_hooks();

/**
 *  Initialize Hooks
 */
function ewsalvage_init_hooks()
{

    /**
     * Activation/Deactivation
     */
    register_activation_hook(ewsalvage_PLUGIN_FILE, 'ewsalvage_activation');
    register_deactivation_hook(ewsalvage_PLUGIN_FILE, 'ewsalvage_deactivation');

    /**
     * Enqueue Admin/Front styles and scripts
     */
    add_action('admin_enqueue_scripts', 'ewsalvage_enqueue_admin_scripts');
    add_action('wp_enqueue_scripts', 'ewsalvage_enqueue_scripts');

    /**
     *  Ajax requests
     */
    add_action('wp_ajax_ewsalvage_sync_ewsalvage_products', 'ewsalvage_sync_ewsalvage_products');

    /**
     * Schedule task
     */
    // add_action('ewsalvage_scheduled_tasks', 'ewsalvage_sync_ewsalvage_products');
    // add_filter('cron_schedules', 'ewsalvage_cronjob_schedules');

    // add_action('admin_menu', 'ewsalvage_admin_menu_page');

}

/**
 * Set schedule on plugin activation
 */
function ewsalvage_activation()
{

    // if (!wp_next_scheduled('ewsalvage_scheduled_tasks')) {
    //     wp_schedule_event(time(), 'products_three_times_a_day', 'ewsalvage_scheduled_tasks');
    // }
}

/**
 * Clear schedule on plugin deactivation
 */
function ewsalvage_deactivation()
{
    wp_clear_scheduled_hook('ewsalvage_scheduled_tasks');
}

/**
 * Set cron job schedule
 */
function ewsalvage_cronjob_schedules($schedules)
{

    if (!isset($schedules["products_three_times_a_day"])) {

        $schedules["products_three_times_a_day"] = array(
            'interval' => 8 * 60 * 60,
            'display' => __('After every 8 hours'),
        );

    }
    return $schedules;
}

/**
 * Define ewsalvage Api Constants.
 */
function ewsalvage_define_constants($version)
{

    define('ewsalvage_PLUGIN_FILE', __FILE__);
    define('ewsalvage_VERSION', $version);

}

/**
 *  Enqueue all admin styles and scripts
 */
function ewsalvage_enqueue_admin_scripts()
{

    wp_enqueue_style('ewsalvage-api', plugins_url('/assets/admin/css/ewsalvage.css', ewsalvage_PLUGIN_FILE), array(), ewsalvage_VERSION);
    wp_enqueue_script('ewsalvage-api', plugins_url('/assets/admin/js/ewsalvage.js', ewsalvage_PLUGIN_FILE), ['jquery'], ewsalvage_VERSION);

}

/**
 * Enqueue all frontend styles and scripts
 */
function ewsalvage_enqueue_scripts()
{

    wp_enqueue_style('ewsalvage-api', plugins_url('/assets/css/ewsalvage.css', ewsalvage_PLUGIN_FILE), array(), ewsalvage_VERSION);
    wp_enqueue_script('ewsalvage-api', plugins_url('/assets/js/ewsalvage.js', ewsalvage_PLUGIN_FILE), ['jquery'], ewsalvage_VERSION, true);
}

function ewsalvage_admin_menu_page()
{

    add_submenu_page(
        'edit.php?post_type=product',
        'Ewsalvage Settings',
        'Ewsalvage Settings',
        'manage_options',
        'ewsalvage-settings',
        'ewsalvage_listting_setting_page'
    );

}

/**
 *  setting page
 */
function ewsalvage_listting_setting_page()
{

    global $wpdb;
    if (isset($_POST['submit'])) {

        update_option('ewsalvage_username', sanitize_text_field($_POST['ewsalvage_username']));
        update_option('ewsalvage_password', sanitize_text_field($_POST['ewsalvage_password']));

    }
    ?>

    <form method="POST" action="" class="ewsalvage-settings" autocomplete="off">
        <div class="wrap" id="ewsalvage_setting_page">
            <h1>Settings</h1>
            <table class="form-table" role="presentation">
                <tbody>
                    <tr>
                        <td colspan="2" class="heading-pad">
                            <h4 class="setting-headings"> ewsalvage Portal Credentials <img src="<?php echo plugin_dir_url(__FILE__) . "/assets/images/api_logo.png" ?>" alt="Drezgo API" class="src setting-page-api-logo"></h4>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="username">Username</label>
                        </th>
                        <td>
                            <input name="ewsalvage_username" type="text" id="ewsalvage_username" value="<?php echo get_option("ewsalvage_username"); ?>" class="regular-text" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="password">Password</label>
                        </th>
                        <td>
                            <input name="ewsalvage_password" type="text" id="ewsalvage_password" value="<?php echo get_option("ewsalvage_password"); ?>" class="regular-text" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"></th>
                        <td>
                            <input type="submit" name="submit" class="ewsalvage_submit button button-primary" value="Submit">
                        </td>
                    </tr>
                </tbody>
           </table>
       </div>
   </form>

   <?php
}

/**
 * ewsalvage_execute_curl_call
 *
 * @return void
 */
function ewsalvage_execute_curl_call($endpoint, $method = "GET", $body = "")
{

    // $username = get_option('ewsalvage_username');
    // $password = get_option('ewsalvage_password');

    // $token = base64_encode($username . ':' . $password);

    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => ewsalvage_API_BASE_URL . $endpoint,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_POSTFIELDS => $body,
        CURLOPT_HTTPHEADER => array(),
    ));

    $response = curl_exec($curl);

    curl_close($curl);
    return json_decode($response, true);

}

/**
 * ewsalvage_execute_post_curl_call
 *
 * @return void
 */
function ewsalvage_execute_post_curl_call($endpoint, $body = [])
{

    $username = get_option('ewsalvage_username');
    $password = get_option('ewsalvage_password');

    $token = base64_encode($username . ':' . $password);

    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => ewsalvage_API_BASE_URL . $endpoint,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => json_encode($body),
        CURLOPT_HTTPHEADER => array(
            'Accept: application/json',
            'Content-Type: application/x-www-form-urlencoded',
            'Authorization: Basic ' . $token,
        ),
    ));

    $response = curl_exec($curl);

    curl_close($curl);
    return json_decode($response, true);

}

/**
 * Fetch data from database
 */
function ewsalvage_get_product_id($key, $value)
{

    global $wpdb;
    return $wpdb->get_var($wpdb->prepare("SELECT post_id from {$wpdb->postmeta} WHERE meta_key = '{$key}' AND meta_value = %s", $value));

}

/**
 * Create a log file to write the start time of cron job
 */
function ewsalvage_log_request($counter)
{

    $file = home_url() . '/wp-content/plugins/ewsalvage/cronjob.txt';
    $current = ewsalvage_file_get_contents($file);
    $current = $current . "\n  Counter = " . $counter . "\n  Time = " . date('Y-d-m H:i:s') . "\n " ;
	ewsalvage_file_put_contents($file, $current);
}

/**
 * Sync ewsalvage Products
 */
function ewsalvage_sync_ewsalvage_products()
{

    $file = plugin_dir_path(__FILE__) . '/products_feed.json';
    $products_feed = file_get_contents( $file );

    $feed_last_updated = get_option( 'ewsalvage_products_feed_last_updated', '' ); 
    $current_date      = date('Y-m-d');

    if( empty( $products_feed ) || ( !empty( $feed_last_updated ) && ( $feed_last_updated < $current_date ) ) ) {

        $products_endpoint = "jsonfeed4.php";
        $products_feed = ewsalvage_execute_curl_call($products_endpoint, "GET");
        update_option( 'ewsalvage_products_feed_last_updated', date('Y-m-d') );
        update_option( 'ewsalvage_products_feed_last_updated_testing', date('Y-m-d H:i:s') );
        file_put_contents( $file, json_encode($products_feed) );

    }

    if (!empty($products_feed)) {

        $products_feed = is_array( $products_feed ) ? $products_feed : json_decode( $products_feed, true );

        if( isset( $products_feed['items'] ) ) {

            $counter = 0;
            foreach ($products_feed['items'] as $product) {

                // check if exists
                $maybe_post_id = ewsalvage_get_product_id('_sku', $product['itemid']);
                $post_id = $maybe_post_id ? $maybe_post_id : 0;
    
                // create or update
                ewsalvage_update_ewsalvage_products('product', $post_id, $product);
                $counter++;
    
                $ewsalvage_script_log[] = array(
                    'date' => date('Y-m-d H:i:s'),
                    'counter' => $counter,
                    'post_id' => $post_id
                );
    
                update_option( 'ewsalvage_script_log', $ewsalvage_script_log );
    
                if( $counter == 500 ) {
                    exit("AFTER 500");
                }
            }

        }

    }

    echo json_encode(array(
        'success' => true,
        'message' => 'All products synced',
    ));
    wp_die();

}

/**
 * ewsalvage_update_ewsalvage_products
 *
 * @param  mixed $post_type
 * @param  mixed $post_id
 * @param  mixed $location
 * @return void
 */
function ewsalvage_update_ewsalvage_products($post_type, $post_id, $product)
{

    $sku = $product['itemid'];
    $name = $product['title'];
    $description = !empty($product['description']) ? $product['description'] : '';
    $price = $product['price'];
    $ewsalvage_category_id = $product['category'];
    $ewsalvage_category_name = $product['categoryname'];
    $ewsalvage_top_category_id = $product['topcategory'];
    $ewsalvage_top_category_name = $product['topcategoryname'];
    $tax_class = $product['taxclass'];
    $image = $product['image'];
    $thumbnail_image = $product['thumbimage'];
    $age = $product['age'];
    $ewsalvage_last_updated = $product['lastupdated'];
    $storename = $product['storename'];
    $ewsalvage_location_id = $product['location'];
    $quantity = $product['quantity'];
    $units = $product['units'];
    $hold_quantity = $product['holdquantity'];
    $extraimages = $product['extraimages'];
    $extrathumbimages = $product['extrathumbimages'];
    $tags = $product['tags'];
    
    $status = 'publish';

    // get user id by email
    $admin_email = get_option('admin_email');
    $the_user = get_user_by('email', $admin_email);
    $user_id = $the_user->ID;

    if ((int) $post_id > 0) {

        wp_update_post(
            array(
                'ID' => $post_id,
                'post_type' => $post_type,
                'post_title' => $name,
                'post_content' => '',
                'post_excerpt' => $description,
            )
        );

    } else {

        $post_id = wp_insert_post(
            array(
                'post_title' => $name,
                'post_type' => $post_type,
                'post_status' => $status,
                'post_excerpt' => $description,
            )
        );

        update_post_meta($post_id, '_sku', $sku);


        if( !empty( $image ) ) {

            $feature_image_id = ewsalvage_upload_media($image);
            update_post_meta($post_id, '_thumbnail_id', $feature_image_id);

        }

        $gallery_images = array();
        if (!empty($extraimages)) {

            if (count($extraimages) > 0) {

                foreach ($extraimages as $image) {

                    $gallery_id = ewsalvage_upload_media($image);
                    array_push($gallery_images, $gallery_id);

                }
                update_post_meta($post_id, 'gallery', $gallery_images);
                update_post_meta($post_id, '_product_image_gallery', implode(",", $gallery_images));

            }

        }

    }

    update_post_meta($post_id, '_sku', $sku);
    update_post_meta($post_id, '_stock', $quantity);
    update_post_meta($post_id, '_manage_stock', 'no');
    update_post_meta($post_id, '_weight', '');
    update_post_meta($post_id, 'ewsalvage_json_data', json_encode($product));
    update_post_meta($post_id, 'ewsalvage_sync', "yes");
    update_post_meta($post_id, "_regular_price", $price);
    update_post_meta($post_id, "_price", $price);
    update_post_meta($post_id, "_ewsalvage_age", $age);
    update_post_meta($post_id, "_ewsalvage_last_updated", $ewsalvage_last_updated);
    update_post_meta($post_id, "_ewsalvage_storename", $storename);
    update_post_meta($post_id, "_ewsalvage_location_id", $ewsalvage_location_id);
    update_post_meta($post_id, '_ewsalvage_host_quantity', $hold_quantity);
    update_post_meta($post_id, '_ewsalvage_extraimages', $extraimages);
    update_post_meta($post_id, '_ewsalvage_extrathumbimages', $extrathumbimages);
    update_post_meta($post_id, '_ewsalvage_tags', $tags);


    // parent category
    $parent_id = 0;
    if (!empty( $ewsalvage_top_category_name ) ) {
        $parent_id = ewsalvage_create_product_category($ewsalvage_top_category_name, $post_id, 'product_cat');
    }

    if( is_array( $parent_id ) ) {

        $parent_id = $parent_id[0];

    }

    // child category
    $child_one = 0;
    if (!empty($ewsalvage_category_name)) {

        $child_one = ewsalvage_create_product_category($ewsalvage_category_name, $post_id, 'product_cat', $parent_id);
    }

    // location category
    if (!empty($storename)) {
        ewsalvage_create_product_category($storename, $post_id, 'product_location');
    }

}

/**
 * Create Product Terms
 */
function ewsalvage_create_product_term($name, $option, $product_id)
{

    $attributes = [];
    if ($name == "sellingPrice") {
        $label = "Price";
    } else {
        $label = ucwords($name);
    }

    $sanitize = sanitize_title($label);
    $slug = 'pa_' . $sanitize;

    $attribute_name_array = wc_get_attribute_taxonomy_names();
    if (!in_array($slug, $attribute_name_array)) {
        $taxonomy_name = $slug;
        $attribute_id = wc_create_attribute(array(
            'name' => $label,
            'slug' => $slug,
            'type' => 'select',
            'order_by' => 'menu_order',
            'has_archives' => false,
        ));
        register_taxonomy(
            $taxonomy_name,
            apply_filters('woocommerce_taxonomy_objects_' . $taxonomy_name, array('product')),
            apply_filters('woocommerce_taxonomy_args_' . $taxonomy_name,
                array(
                    'labels' => array('name' => $label),
                    'hierarchical' => true,
                    'show_ui' => false,
                    'query_var' => true,
                    'rewrite' => false,
                ))
        );
        delete_transient('wc_attribute_taxonomies');
    }
    $option = (array) $option;
    if (count($option) > 1) {
        if ($name == "weight") {
            // Variation tile (Weight - Size - Legnth - locationcode)
            $size = !empty($option['size']) ? $option['size'] . " sz - " : '';
            $length = !empty($option['length']) ? $option['length'] . " cm - " : '';
            $value = $size . $length;
            // End
            //$value = $option[$name]."gm - ".$option['locationCode'];
        } else {
            $value = $option[$name];
        }
        $is_variation = 1;
    } else {
        if ($name == "weight") {
            $value = $option[0] . "gm";
        } else {
            $value = $option[0];
        }
        $is_variation = 0;
    }

    if (!empty($value)) {
        $attributes[$slug] = array(
            'name' => $slug,
            'value' => str_replace(".", "-", $value),
            'is_visible' => '1',
            'is_variation' => $is_variation,
            'is_taxonomy' => '1',
        );
        ewsalvage_create_product_category($value, $product_id, $slug);
    }
    return $attributes;
}

/**
 * Create Product Categories
 */
function ewsalvage_create_product_category($name, $id, $type, $parent = 0)
{
    $name = (string) $name;
    if (!empty($name)) {
        //$name = htmlspecialchars_decode($name);
        if ($parent == 0) {
            $terms = term_exists($name, $type);
            if ($terms !== 0 && $terms !== null) {
                $terms = (array) $terms;
                $term_id = $terms['term_id'];
            } else {
                $terms = wp_insert_term($name, $type);
                $term_id = (array) $terms['term_id'];
            }
        } else {
            $childs = get_terms($type, array('parent' => $parent, 'hide_empty' => false));
            $termName = [];
            foreach ($childs as $child) {
                $child = (array) $child;
                $termName[$child['term_id']] = $child['name'];
            }
            $array_flip = array();
            $array_flip = array_flip($termName);
            if (!empty($array_flip[$name])) {
                $term_id = $array_flip[$name];
            } else {
                $terms = wp_insert_term($name, $type, array('parent' => $parent));
                $terms = (array) $terms;
                $term_id = $terms['term_id'];
            }
        }
        wp_set_object_terms($id, (array) $name, $type, true);
        return $term_id;
    }
}

/**
 *  Set product media
 */
function ewsalvage_upload_media($url, $extention = '')
{

    $upload_dir = wp_upload_dir();
    $image_data = ewsalvage_file_get_contents($url);
    $filename = rand() . '-' . str_replace("%","", basename($url));

    $file = (wp_mkdir_p($upload_dir['path'])) ? $upload_dir['path'] . '/' . $filename : $upload_dir['basedir'] . '/' . $filename;

    file_put_contents($file, $image_data);

    $wp_filetype = wp_check_filetype($filename, null);
    $attachment = array(
        'post_mime_type' => $wp_filetype['type'],
        'post_title' => sanitize_file_name($filename),
        'post_content' => '',
        'post_status' => 'inherit',
    );

    // if exists already fetch and send attachment ID
//     if (post_exists(sanitize_file_name($filename))) {
//         $attachment = get_page_by_title(sanitize_file_name($filename), OBJECT, 'attachment');
//         if (!empty($attachment)) {
//             return $attachment->ID;
//         }
//     }

    $attach_id = wp_insert_attachment($attachment, $file);

    require_once ABSPATH . 'wp-admin/includes/image.php';

    $attach_data = wp_generate_attachment_metadata($attach_id, $file);

    wp_update_attachment_metadata($attach_id, $attach_data);
    return $attach_id;
}

/**
 * ewsalvage_file_get_contents
 *
 * @param  mixed $url
 * @return void
 */
function ewsalvage_file_get_contents($url)
{

    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
    ));

    $response = curl_exec($curl);

    curl_close($curl);
    return $response;

}

/**
 * ewsalvage_file_put_contents
 *
 * @param  mixed $url
 * @return void
 */
function ewsalvage_file_put_contents($url, $body)
{

    $curl = curl_init();

    echo $url;
    curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'PUT',
        CURLOPT_POSTFIELDS => json_encode($body),
    ));

    $response = curl_exec($curl);

    curl_close($curl);
    return $response;

}


/**
 *  Debugging
 */
add_action('wp_loaded', function(){

    if( isset( $_REQUEST['page'] ) && $_REQUEST['page'] == 'phpinfo' ) {


        echo phpinfo();

        exit("HERE");

    }

    if( isset( $_REQUEST['page']) && $_REQUEST['page'] == 'ewsalvage_log' ) {

        $ewsalvage_script_log = get_option('ewsalvage_script_log', []);

        echo "<pre>";
        print_r( $ewsalvage_script_log );
        echo "</pre>";

        exit("LOG");

    }

    if( isset( $_REQUEST['page']) && $_REQUEST['page'] == 'ewsalvage_sync_products' ) {

        ewsalvage_sync_ewsalvage_products();

        exit("SYNC PRODUCTS");

    }

});


function ewsalvage_delete_all_products() {


    $all_post_ids = get_posts(array(
        'fields'          => 'ids',
        'posts_per_page'  => -1,
        'post_type' => 'product'
    ));


    if( !empty( $all_post_ids ) ) {

        foreach( $all_post_ids as $product_id ) {

            // Delete product data
            if(has_post_thumbnail( $product_id ))
            {
                $attachment_id  = get_post_thumbnail_id( $product_id );
                wp_delete_attachment($attachment_id, true );
            }

            wp_delete_post( $product_id, true );


        }

    }
    
}

add_action( 'init', 'ewsalvage_custom_taxonomy_location' );
function ewsalvage_custom_taxonomy_location()  {
    $labels = array(
        'name'                       => 'locations',
        'singular_name'              => 'location',
        'menu_name'                  => 'location',
        'all_locations'                  => 'All locations',
        'parent_location'                => 'Parent location',
        'parent_location_colon'          => 'Parent location:',
        'new_location_name'              => 'New location Name',
        'add_new_location'               => 'Add New location',
        'edit_location'                  => 'Edit location',
        'update_location'                => 'Update location',
        'separate_locations_with_commas' => 'Separate location with commas',
        'search_locations'               => 'Search locations',
        'add_or_remove_locations'        => 'Add or remove locations',
        'choose_from_most_used'      => 'Choose from the most used locations',
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => true,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => false,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => true,
    );
    register_taxonomy( 'product_location', 'product', $args );
    register_taxonomy_for_object_type( 'product_location', 'product' );
}


function ewas_settings_metabox()
{

    $post_id = get_the_ID();
    
    $ewas_catalog_only = get_post_meta( $post_id, 'ewas_catalog_only', true );
    $ewas_pickup_text  = get_post_meta( $post_id, 'ewas_pickup_text', true );
    $ewas_hide_pickup_text = get_post_meta( $post_id, 'ewas_hide_pickup_text', true );

    ?>
        <div id="general_product_data" class="panel woocommerce_options_panel" style="">
            <div class="options_group" style="display: block;">
                <p class="form-field" style="line-height:1.5;">
                    <label for="ewas_catalog_only">Catalog Only</label>
                    <input type="checkbox" class="" style="" name="ewas_catalog_only" id="ewas_catalog_only" value="1" <?php echo !empty( $ewas_catalog_only ) ? 'checked' : ''; ?>>
                    <small style="margin-left:10px;">Yes | No, Default: <span style="font-weight: 800;">No</span></small>
                </p>
                <p class="form-field" style="line-height:1.5;">
                    <label for="ewas_hide_pickup_text">Hide Pickup Text</label>
                    <input type="checkbox" class="" style="" name="ewas_hide_pickup_text" id="ewas_hide_pickup_text" value="1" <?php echo !empty( $ewas_hide_pickup_text ) ? 'checked' : ''; ?>>
                    <small style="margin-left:10px;">Yes | No, Default: <span style="font-weight: 800;">No</span></small>
                </p>
                <p class="form-field" style="line-height:1.5;">
                    <label for="ewas_pickup_text">Pickup Text</label>
                    <input type="text" class="short" style="" name="ewas_pickup_text" id="ewas_pickup_text" value="<?php echo $ewas_pickup_text; ?>" placeholder="">
                    </br></br>
                    <span style="text-align:center;font-weight:bold;">Default: Must be Picked Up at [[location_name]] Store.</span>
                </p>	
            </div>
        </div>
    <?php
}

function ewas_add_custom_meta_box()
{
    add_meta_box("ewas-settings-meta-box", "Ewas Settings", "ewas_settings_metabox", "product", "normal", "high", null);
}

add_action("add_meta_boxes", "ewas_add_custom_meta_box");


add_action( 'save_post', 'ewas_create_or_update_product', 10, 3);

function ewas_create_or_update_product($post_id, $post, $update){
    if ($post->post_status != 'publish' || $post->post_type != 'product') {
        return;
    }

    if (!$product = wc_get_product( $post )) {
        return;
    }

    // Make something with $product
    // You can also check $update

    // pickup text
    if( isset( $_POST['ewas_pickup_text'] ) ) {

        $ewas_pickup_text = $_POST['ewas_pickup_text'];
        update_post_meta( $post_id, 'ewas_pickup_text', $ewas_pickup_text );

    }

    // catalog only checkbox
    if( isset( $_POST['ewas_catalog_only'] ) && !empty( $_POST['ewas_catalog_only'] ) ) {

        $ewas_catalog_only = $_POST['ewas_catalog_only'];
        update_post_meta( $post_id, 'ewas_catalog_only', $ewas_catalog_only );

    } else {
        update_post_meta( $post_id, 'ewas_catalog_only', '' );
    }

    // pickup text checkbox
    if( isset( $_POST['ewas_hide_pickup_text'] ) && !empty( $_POST['ewas_hide_pickup_text'] ) ) {

        $ewas_hide_pickup_text = $_POST['ewas_hide_pickup_text'];
        update_post_meta( $post_id, 'ewas_hide_pickup_text', $ewas_hide_pickup_text );

    } else {
        update_post_meta( $post_id, 'ewas_hide_pickup_text', '' );
    }
}