!function($, window, document, _undefined)
{
	$(function()
	{
		$(document).ready(function()
		{
            
        });
        
    });
}(jQuery, this, document);