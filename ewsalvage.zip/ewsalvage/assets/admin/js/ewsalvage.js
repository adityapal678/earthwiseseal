!(function ($, window, document, _undefined) {
  jQuery(function () {
    jQuery(document).ready(function () {
      jQuery("#ewsalvage_sync").click(function (e) {
        var $button = jQuery(e.target).prop("disabled", true);
        var $spin = $button.next(".spinner").addClass("is-active");
        $.ajax({
          type: "POST",
          url: ajaxurl,
          dataType: "json",
          data: {
            action: "ewsalvage_sync_ewsalvage_products",
          },
          success: function (response) {
            console.log(response);
            $button.prop("disabled", false);
            $spin.removeClass("is-active");
          },
          error: function () {
            $button.prop("disabled", false);
            $spin.removeClass("is-active");
          },
        });
      });
    });

    // Add buttons to product screen.
    var $product_screen = $(".edit-php.post-type-product");
    var $title_action = $product_screen.find(".page-title-action");
    var $product = $title_action.after(
      '<button id="ewsalvage_sync" class="page-title-action">Ewsalvage Sync</button><span class="spinner spinner-ewsalvage"></span>'
    );
  });
})(jQuery, this, document);
